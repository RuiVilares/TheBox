void start_menu();

void movieclub_menu();

void tv_menu();

void advanced_menu1();

void advanced_menu2();

void endprogram_menu();

void welcome();

void goodbye();

void ListbyDay();

void ListbyChannel();

void ListbyType();

void EditPass();

void EditChannels();

void EditPrograms();

void EditMovies();