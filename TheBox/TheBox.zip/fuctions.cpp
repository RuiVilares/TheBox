#include <iostream> 
#include <iomanip> 
#include <string>
#include <cctype> 
#include <cstddef> 
#include <vector>
#include <fstream>
#include <algorithm> 
#include "stdlib.h"
#include <windows.h>
#include "fuctions.h"

using namespace std;

void RentMovie()
{
	// Completar depois
}

void ListNeverSeen()
{
	// Completar
}

void ListPreviouslySeen()
{
	// Completar
}

void MoneySpent()
{
	// Completar
}

