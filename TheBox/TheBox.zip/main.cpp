#include "menu.h"
#include <windows.h>

int main()
{
	welcome();
	Sleep(2000);
	start_menu();
	return 0;
}