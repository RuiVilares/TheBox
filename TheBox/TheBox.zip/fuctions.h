void RentMovie();

void ListNeverSeen();

void ListPreviouslySeen();

void MoneySpent();