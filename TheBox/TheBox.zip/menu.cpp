﻿#include <iostream> 
#include <iomanip> 
#include <string>
#include <cctype> 
#include <cstddef> 
#include <vector>
#include <fstream>
#include <algorithm> 
#include "stdlib.h"
#include <windows.h>
#include <conio.h>
#include "menu.h"
#include "fuctions.h"

using namespace std;

void welcome()
{
	cout << endl << endl << endl << endl;
	cout <<  " __        __   _                          " << endl;
	cout <<  " \\ \\      / /__| | ___ ___  _ __ ___   ___ " << endl;
	cout <<  "  \\ \\ /\\ / / _ \\ |/ __/ _ \\| '_ ` _ \\ / _ \\" << endl;
	cout <<  "   \\ V  V /  __/ | (_| (_) | | | | | |  __/" << endl;
	cout <<  "    \\_/\\_/ \\___|_|\\___\\___/|_| |_| |_|\\___|" << endl << endl << endl;
}

void goodbye()
{
	system("CLS");
	cout << endl << endl << endl << endl;
	cout << "   ____                 _ _                " << endl;
	cout << "  / ___| ___   ___   __| | |__  _   _  ___ " << endl;
	cout << " | |  _ / _ \\ / _ \\ / _` | '_ \\| | | |/ _ \\" << endl;
	cout << " | |_| | (_) | (_) | (_| | |_) | |_| |  __/" << endl;
	cout << "  \\____|\\___/ \\___/ \\__,_|_.__/ \\__, |\\___|" << endl;
	cout << "                                |___/      " << endl << endl << endl;
	exit(0);
}

void movieclub_menu()
{
	int yourchoice;
	bool valid = false;
	system("CLS");
	cout << "  __  __            _             _       _     " << endl;
	cout << " |  \\/  | _____   _(_) ___    ___| |_   _| |__  " << endl;
	cout << " | |\\/| |/ _ \\ \\ / / |/ _ \\  / __| | | | | '_ \\ " << endl;
	cout << " | |  | | (_) \\ V /| |  __/ | (__| | |_| | |_) |" << endl;
	cout << " |_|  |_|\\___/ \\_/ |_|\\___|  \\___|_|\\__,_|_.__/ " << endl << endl << endl;
	cout << "1. Rent a movie" << endl;
	cout << "2. List of movies never seen" << endl;
	cout << "3. List of movies previously seen" << endl;
	cout << "4. Money spent in watching movies" << endl;
	cout << "5. Return back" << endl << endl;
	do
	{
		cout << "Choose one of those options: ";
		cin >> yourchoice;
		if (yourchoice >= 1 && yourchoice <= 5)
			valid = true;
		else
			// corrigir o que acontece quando metes crtl+z e quando metes uma string comprida
		{
			cin.clear();
			cin.ignore();
			cout << endl << "Invalid option" << endl << endl; 
			Sleep(1000);
			movieclub_menu();
		}
	} 
	while (!valid);
	
	if (yourchoice == 1)
		RentMovie();
	if (yourchoice == 2)
		ListNeverSeen();
	if (yourchoice == 3)
		ListPreviouslySeen();
	if (yourchoice == 4)
		MoneySpent();
	if (yourchoice == 5)
		start_menu();
}

void tv_menu()
{
	int yourchoice;
	bool valid = false;
	system("CLS");
	cout << "  _____    _            _     _             " << endl;
	cout << " |_   _|__| | _____   _(_)___(_) ___  _ __  " << endl;
	cout << "   | |/ _ \\ |/ _ \\ \\ / / / __| |/ _ \\| '_ \\ " << endl;
	cout << "   | |  __/ |  __/\\ V /| \\__ \\ | (_) | | | |" << endl;
	cout << "   |_|\\___|_|\\___| \\_/ |_|___/_|\\___/|_| |_|" << endl << endl << endl;
	cout << "1. List the programs by day" << endl;
	cout << "2. List the programs by channel" << endl;
	cout << "3. List the programs by type of program" << endl;
	cout << "4. Return back" << endl << endl;
	do
	{
		cout << "Choose one of those options: ";
		cin >> yourchoice;
		if (yourchoice >= 1 && yourchoice <= 5)
			valid = true;
		else
			// corrigir o que acontece quando metes crtl+z e quando metes uma string comprida
		{
			cin.clear();
			cin.ignore();
			cout << endl << "Invalid option" << endl << endl; 
			Sleep(1000);
			movieclub_menu();
		}
	} 
	while (!valid);
	
	if (yourchoice == 1)
		ListbyDay();
	if (yourchoice == 2)
		ListbyChannel();
	if (yourchoice == 3)
		ListbyType();
	if (yourchoice == 4)
		start_menu();
}

// Password pré-definida, versão apenas de teste... Pass é "cenas"
void advanced_menu1()
{
	system("CLS");
	cout << "     _       _                               _ " << endl;
	cout << "    / \\   __| |_   ____ _ _ __   ___ ___  __| |" << endl;
	cout << "   / _ \\ / _` \\ \\ / / _` | '_ \\ / __/ _ \\/ _` |" << endl;
	cout << "  / ___ \\ (_| |\\ V / (_| | | | | (_|  __/ (_| |" << endl;
	cout << " /_/   \\_\\__,_| \\_/ \\__,_|_| |_|\\___\\___|\\__,_|" << endl << endl << endl;
	cout << "Please insert your password: ";
	string pass ="";
	char ch;
	ch = _getch();
	while(ch != 13) //character 13 is enter
	{
      if (ch == 8)
	  {
		  advanced_menu1();
	  }
	  else
	  {
		pass.push_back(ch);
		cout << '*';
		ch = _getch();
	  }
	}
	if(pass == "cenas")
	{
      advanced_menu2();
	}
	else
	{
		cout << endl << endl << "Incorrect password" << endl;
		Sleep(1000);
		start_menu();
	}
}

void advanced_menu2()
{
	int yourchoice;
	bool valid = false;
	system("CLS");
	cout << "     _       _                               _ " << endl;
	cout << "    / \\   __| |_   ____ _ _ __   ___ ___  __| |" << endl;
	cout << "   / _ \\ / _` \\ \\ / / _` | '_ \\ / __/ _ \\/ _` |" << endl;
	cout << "  / ___ \\ (_| |\\ V / (_| | | | | (_|  __/ (_| |" << endl;
	cout << " /_/   \\_\\__,_| \\_/ \\__,_|_| |_|\\___\\___|\\__,_|" << endl << endl << endl;
	cout << "You are in a privileged user menu, please don't change anything without the" << endl;
	cout << "certainty. The box allows for CRUD operations (Create, Read, Update, Delete)." << endl << endl;
	cout << "1. Password" << endl;
	cout << "2. Channels" << endl;
	cout << "3. Programs" << endl;
	cout << "4. Movies" << endl;
	cout << "5. Return back" << endl << endl;
	do
	{
		cout << "Choose one of those options: ";
		cin >> yourchoice;
		if (yourchoice >= 1 && yourchoice <= 5)
			valid = true;
		else
			// corrigir o que acontece quando metes crtl+z e quando metes uma string comprida
		{
			cin.clear();
			cin.ignore();
			cout << endl << "Invalid option" << endl << endl; 
			Sleep(1000);
			movieclub_menu();
		}
	} 
	while (!valid);
	
	if (yourchoice == 1)
		EditPass();
	if (yourchoice == 2)
		EditChannels();
	if (yourchoice == 3)
		EditPrograms();
	if (yourchoice == 4)
		EditMovies();
	if (yourchoice == 5)
		start_menu();
}


void endprogram_menu()
{
	int yourchoice;
	bool valid = false;
	system("CLS");
	cout << "  _____           _   ____                                      " << endl;
	cout << " | ____|_ __   __| | |  _ \\ _ __ ___   __ _ _ __ __ _ _ __ ___  " << endl;
	cout << " |  _| | '_ \\ / _` | | |_) | '__/ _ \\ / _` | '__/ _` | '_ ` _ \\ " << endl;
	cout << " | |___| | | | (_| | |  __/| | | (_) | (_| | | | (_| | | | | | |" << endl;
	cout << " |_____|_| |_|\\__,_| |_|   |_|  \\___/\\ \__, |_|  \\__,_|_| |_| |_|" << endl;
	cout << "                                      |___/                     " << endl << endl << endl;
	cout << "Are you sure that you want to exit the program?" << endl << endl;
	cout << "1. Yes" << endl;
	cout << "2. No" << endl << endl;
	do
	{
		cout << "Choose one of those options: ";
		cin >> yourchoice;
		if (yourchoice >= 1 && yourchoice <= 2)
			valid = true;
		else
			// corrigir o que acontece quando metes crtl+z e quando metes uma string comprida
		{
			cin.clear();
			cin.ignore();
			cout << endl << "Invalid option" << endl << endl; 
			Sleep(1000);
			endprogram_menu();
		}
	} 
	while (!valid);
	
	if (yourchoice == 1)
		goodbye();
	if (yourchoice == 2)
		start_menu();
}

// Colocar data no menu iniciar
// Cuidado porque quando meto numero com mais de 1 digito fica no buffer e dá asneira ao compilar
void start_menu()
{
	system("CLS");
	int yourchoice;
	bool valid = false;
	cout << "  ____  _             _     __  __                  " << endl;
	cout << " / ___|| |_ __ _ _ __| |_  |  \\/  | ___ _ __  _   _ " << endl;
	cout << " \\___ \\| __/ _` | '__| __| | |\\/| |/ _ \\ '_ \\| | | |" << endl;
	cout << "  ___) | || (_| | |  | |_  | |  | |  __/ | | | |_| |" << endl;
	cout << " |____/ \\__\\__,_|_|   \\__| |_|  |_|\\___|_| |_|\\__,_|" << endl << endl << endl;
	
	cout << "1. Movieclube" << endl;
	cout << "2. Television" << endl;
	cout << "3. Advanced options" << endl;
	cout << "4. Exit" << endl << endl;
	
	
	do
	{
		cout << "Choose one of those options: ";
		cin >> yourchoice;
		if (yourchoice >= 1 && yourchoice <= 4)
		{
			valid = true;
		}
		
		else
			// corrigir o que acontece quando metes crtl+z e quando metes uma string comprida
		{
			cin.ignore();
			cin.clear();
			cout << endl << "Invalid option" << endl << endl; 
			Sleep(1000);
			start_menu();
		}
	} 
	while (!valid);
	
	if (yourchoice == 1)
		movieclub_menu();
	if (yourchoice == 2)
		tv_menu();
	if (yourchoice == 3)
		advanced_menu1();
	if (yourchoice == 4)
		endprogram_menu();
	
	//system("CLS");	
}

void ListbyDay()
{
	// Completar
}

void ListbyChannel()
{
	// Completar
}

void ListbyType()
{
	// Completar
}

void EditPass()
{
	//Completar
}

void EditChannels()
{
	//Completar
}

void EditPrograms()
{
	//Completar
}

void EditMovies()
{
	//Completar
}